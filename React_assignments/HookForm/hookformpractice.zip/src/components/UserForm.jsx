import {useState} from "react";


const UserForm = (props) => {
    const [firstname, setFirstName] = useState("");
    const [lastname, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmpassword, setConfirmPassword] = useState("");
    const {users} = props
    const [allusers, setUsers] = useState(users)

    const createUser = (e) => {
    e.preventDefault();

    const newUser = {firstname, lastname, email, password, confirmpassword};
    setFirstName("");
    setLastName("");
    setEmail("");
    setPassword("");
    setConfirmPassword("");
    setUsers("");
    };
    return (
        <>
        <fieldset>
            <legend>UserForm.jsx</legend>
        <form onSubmit= {createUser}>
            <div>
                <label>First Name:</label>
                <input type="text" value={firstname} onChange={(e) =>
                setFirstName(e.target.value)} />
            </div>
            <div>
                <label>Last Name:</label>
                <input type="text" value={lastname} onChange={(e) =>
                setLastName(e.target.value)} />
            </div>
            <div>
                <label>Email:</label>
                <input type="text" value={email} onChange={(e) => 
                setEmail(e.target.value)} />
            </div>
            <div>
                <label>Password:</label>
                <input type="password" value={password} onChange={(e) =>
                setPassword(e.target.value)} />
            </div>
            <div>
                <label>Password:</label>
                <input type="password" value={confirmpassword} onChange={(e) =>
                setConfirmPassword(e.target.value)} />
                <input type="submit" value="Create User"/>
            </div>
        </form>
        </fieldset>
        <fieldset>
            <legend>Info</legend>
            <p>{firstname}</p>
            <p>{lastname}</p>
            <p>{email}</p>
            <p>{password}</p>
            <p>{confirmpassword}</p>
        </fieldset>
        <fieldset>
            <legend>Users</legend>
            <h3>All Users</h3>
            <p>{JSON.stringify(allusers)}</p>
            {
                allusers.map((u, index) => {
                    return <div key={index}>
                        <li>{u}</li>
                    </div>
                })
            }
        </fieldset>
        </>
    );
};

export default UserForm