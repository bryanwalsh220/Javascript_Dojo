import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {

  const [pokes, setPokemon] = useState([])

  const fetchPokemon = () => {
    fetch("https://pokeapi.co/api/v2/pokemon?limit=100000&offset=0")
    .then(res => {
      console.log(res)
      return res.json();
    })
    .then(jsonData => {
      console.log(jsonData)
      setPokemon(jsonData.results.slice(0, 807));
    })
    .catch(err =>{
      console.log(err, "ERROR")
    })
  }


  return (
    <> <div className='App'>
    <h1>Pokemon</h1>
  <hr />
  <button onClick={fetchPokemon}>Get those Pokes</button>
  <hr />
  <table>
    <thead>
      <tr>
        <th>Name</th>
        <th>Type</th>
      </tr>
    </thead>
    <tbody>
      {
        pokes.map((poke, idx) => {
          return <tr key={poke.id}>
            <td>{poke.name}</td>
          </tr>
        })
      }
    </tbody>
  </table>
  </div>
    </>
  )
}

export default App
