import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import PersonCard from './components/PersonCard.jsx'

function App() {
  
  return (
    <>
    <div>
      <PersonCard firstName={'Jane'} lastName={"Doe"} age={45} hairColor={"Black"}/>
      <PersonCard firstName={'John'} lastName={"Cena"} age={88} hairColor={"Brown"}/>
      <PersonCard firstName={'Gordon'} lastName={"Ramsey"} age={55} hairColor={"Blonde"}/>
      <PersonCard firstName={'Barney'} lastName={"Dinosaur"} age={100000} hairColor={"Purple"}/>
    </div>
      
    </>
  )
}

export default App
